module LABB6 {
}