module lab2 {
}