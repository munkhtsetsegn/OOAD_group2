package lab2;

public class candy {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
          System.out.println ("Сар шинийн мэнд багшаа"); 
	}

}
