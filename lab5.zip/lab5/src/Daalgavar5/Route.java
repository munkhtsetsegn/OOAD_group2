package Daalgavar5;

	public class Route {
		public int ID;
		public String Name;
		
		
		public Route(int id, String name) {
			ID = id;
			Name = name;
			
			
		}
}
