package Daalgavar5;

public class NaturalBeauty {
	Route rou;
	public int ID;
	public String Name;
	public String Info;
	
	public NaturalBeauty(int id, String name, String info) {
		ID = id;
		Name = name;
		Info = info;
	
	}
}
